## 설치하기

SmartEditor2에 사진 퀵 업로더를 적용하는 방법을 설명한다. 사진 플러그인을 추가하고 툴바에 사진 버튼을 추가한 후 팝업 JavaScript를 수정한다. 다운로드한 SmartEditor2 툴바에 사진 아이콘이 있다면 &quot;[PHP 서버 설정](03.md)&quot;부터 참고한다.
