<?php

// private class for unit testing

class HTMLPurifier_Language_en_x_test extends HTMLPurifier_Language
{
}

// vim: et sw=4 sts=4
