Theme Name: at47_
Theme URI: https://atsotre.co.kr/at47
Maker: 골뱅이스토어
Maker URI: http://atsotre.co.kr
Version: 3.0.0
Detail: [test] 테마는 골뱅이스토어에서 제작하는 테마입니다. [test]테마는 웹표준 및 접근성을 준수합니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html
제작자:박진완