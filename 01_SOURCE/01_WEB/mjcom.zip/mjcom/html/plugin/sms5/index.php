<?php
//SMS5 메인
include_once('./_common.php');

$g5['title'] = "SMS5";
include_once(G5_PATH.'/head.sub.php');

include_once("./write.php");

include_once(G5_PATH.'/tail.sub.php');